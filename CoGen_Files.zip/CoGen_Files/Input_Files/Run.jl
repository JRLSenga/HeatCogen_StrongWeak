"""
DOLPHYN: Decision Optimization for Low-carbon for Power and Hydrogen Networks
Copyright (C) 2021,  Massachusetts Institute of Technology
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
A complete copy of the GNU General Public License v2 (GPLv2) is available
in LICENSE.txt.  Users uncompressing this from an archive may not have
received this license file.  If not, see <http://www.gnu.org/licenses/>.
"""

using CSV
using DataFrames

cd(dirname(@__FILE__))


Optimal_List = []
Scenario_List = []

filename = "Scenarios_Process_Temperatures.csv"

scenarios_in = CSV.read(pwd() * "/" * filename, DataFrame)


num_scenarios = nrow(scenarios_in)




for i in range(1, num_scenarios)

    Scenario_Process_Temperature = scenarios_in[i, :Process_Temperature]

    push!(Scenario_List, i)
    #List that captures the costs of each type of SMR

    Cost_List = []
    SMR_List = ["HTGR", "iMSR", "iPWR", "Microreactor", "PBR-HTGR"]
    SMR_Reactor_Temp = [852, 585, 302, 565, 563] # Manual Input of Reactor Temperature per SMR Type. The order corresponds to the order in SMR_List
    SMR_Condenser_Temp = [30, 30, 30, 30, 30]
    
    # SMR_List = ["HTGR", "iMSR"]
    # SMR_Reactor_Temp = [852,585] # Manual Input of Reactor Temperature per SMR Type. The order corresponds to the order in SMR_List
    # SMR_Condenser_Temp = [30,  30]
    for j in range(1, length(SMR_List))

        if SMR_Reactor_Temp[j] < Scenario_Process_Temperature || SMR_Condenser_Temp[j] >= Scenario_Process_Temperature

            TotalCost = 999999999999999 # A really large number
            push!(Cost_List, TotalCost)
        else 
            setting_iteration = "Parameters/Parameter_1/Settings"

            settings_path = joinpath(pwd(), setting_iteration)
            # settings_path = joinpath(pwd(), "Settings")


            println(settings_path)


            # environment_path = "../../../package_activate.jl"
            # include(environment_path) #Run this line to activate the Julia virtual environment for GenX; skip it, if the appropriate package versions are installed

            # ### Set relevant directory paths
            src_path = "../../../src/"

            inpath_iteration = "Parameters/Parameter_1"

            inpath = joinpath(pwd(), inpath_iteration)


            println(inpath)



            ### Load GenX
            println("Loading packages")
            push!(LOAD_PATH, src_path)


            println(LOAD_PATH)



            # using DOLPHYN
            using GenX
            using YAML

            genx_settings = joinpath(settings_path, "genx_settings.yml") #Settings YAML file path for GenX
            hsc_settings = joinpath(settings_path, "hsc_settings.yml") #Settings YAML file path for HSC modelgrated model
            csc_settings = joinpath(settings_path, "csc_settings.yml") #Settings YAML file path for CSC model
            besc_settings = joinpath(settings_path, "besc_settings.yml") #Settings YAML file path for BESC model
            sf_settings = joinpath(settings_path, "syn_fuel_settings.yml") #Settings YAML file path for SF model

            mysetup_genx = YAML.load(open(genx_settings)) # mysetup dictionary stores GenX-specific parameters
            mysetup_hsc = YAML.load(open(hsc_settings)) # mysetup dictionary stores H2 supply chain-specific parameters
            mysetup_csc = YAML.load(open(csc_settings)) # mysetup dictionary stores CO2 supply chain-specific parameters
            mysetup_besc = YAML.load(open(besc_settings)) # mysetup dictionary stores BESC supply chain-specific parameters
            mysetup_sf = YAML.load(open(sf_settings)) # mysetup dictionary stores SF supply chain-specific parameters

            global_settings = joinpath(settings_path, "global_model_settings.yml") # Global settings for inte
            mysetup_global = YAML.load(open(global_settings)) # mysetup dictionary stores global settings
            mysetup = Dict()
            mysetup = merge(mysetup_sf, mysetup_besc, mysetup_csc, mysetup_hsc, mysetup_genx, mysetup_global) #Merge dictionary - value of common keys will be overwritten by value in global_model_settings
            mysetup["ProcessTemp"] = Scenario_Process_Temperature #Set process temperature based on the scenario --Juan Senga
            println(mysetup)

            println(settings_path)

            ## Cluster time series inputs if necessary and if specified by the user
            TDRpath = joinpath(inpath, mysetup["TimeDomainReductionFolder"])
            if mysetup["TimeDomainReduction"] == 1
                if mysetup["ModelH2"] == 1
                    if (!isfile(TDRpath*"/Load_data.csv")) || (!isfile(TDRpath*"/Generators_variability.csv")) || (!isfile(TDRpath*"/Fuels_data.csv")) || (!isfile(TDRpath*"/HSC_generators_variability.csv")) || (!isfile(TDRpath*"/HSC_load_data.csv"))
                        println("Clustering Time Series Data...")
                        cluster_inputs(inpath, settings_path, mysetup)
                    else
                        println("Time Series Data Already Clustered.")
                    end
                else
                    if (!isfile(TDRpath*"/Load_data.csv")) || (!isfile(TDRpath*"/Generators_variability.csv")) || (!isfile(TDRpath*"/Fuels_data.csv"))
                        println("Clustering Time Series Data...")
                        cluster_inputs(inpath, settings_path, mysetup)
                    else
                        println("Time Series Data Already Clustered.")
                    end
                end
            end



            # ### Configure solver
            println("Configuring Solver")
            OPTIMIZER = configure_solver(mysetup["Solver"], settings_path)

            # #### Running a case

            
                
            #put in the MITC portion for the transmission dual algorithm
            Minimum_Interregional_Transfer_Met = 0

            # while Minimum_Interregional_Transfer_Met == 0
                # ### Load inputs
            println("Loading Inputs")
            myinputs = Dict() # myinputs dictionary will store read-in data and computed parameters
            myinputs, Minimum_Interregional_Transfer_Met = load_inputs(mysetup, inpath, SMR_List[j], i) #changes this to give an output of if the minimum has been met in the transmission dual algorithm - Juan

            

            # ### Generate model
            # println("Generating the Optimization Model")
            EP = generate_model(mysetup, myinputs, OPTIMIZER, inpath)

            ### Solve model
            println("Solving Model")
            EP, solve_time = solve_model(EP, mysetup)
            myinputs["solve_time"] = solve_time # Store the model solve time in myinputs



            ### Write power system output

            println("Writing Output")
            

            outpath = joinpath(pwd(), "Results_" * string(i) * "_" * SMR_List[j])
            # outpath = "$inpath/Results"

            TotalCost = write_outputs(EP, outpath, mysetup, myinputs)

            # Append to Cost_List
            push!(Cost_List, TotalCost)
            print(TotalCost)
            print(Cost_List)
        end

    end

    #determine which one is OPTIMAL

    if minimum(Cost_List) == 999999999999999
        Optimal_SMR = "No SMR can satisfy temperature"
    else
        idx_LowestCost = argmin(Cost_List)
        
        Optimal_SMR = SMR_List[idx_LowestCost]
    end

    push!(Optimal_List, Optimal_SMR)


#output to dataframe
df_Output = DataFrame(Scenario = Scenario_List, LeastCostSMR = Optimal_List)

# Write to CSV
CSV.write("Optimal_List.csv",df_Output)


end

