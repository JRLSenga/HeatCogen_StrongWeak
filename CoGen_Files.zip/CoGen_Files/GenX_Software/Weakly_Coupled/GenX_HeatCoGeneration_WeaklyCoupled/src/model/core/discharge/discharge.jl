@doc raw"""
	discharge(EP::Model, inputs::Dict, setup::Dict)
This module defines the power decision variable $\Theta_{y,t} \forall y \in \mathcal{G}, t \in \mathcal{T}$, representing energy injected into the grid by resource $y$ by at time period $t$.
This module additionally defines contributions to the objective function from variable costs of generation (variable O&M plus fuel cost) from all resources $y \in \mathcal{G}$ over all time periods $t \in \mathcal{T}$:
```math
\begin{aligned}
	Obj_{Var\_gen} =
	\sum_{y \in \mathcal{G} } \sum_{t \in \mathcal{T}}\omega_{t}\times(\pi^{VOM}_{y} + \pi^{FUEL}_{y})\times \Theta_{y,t}
\end{aligned}
```
"""
function discharge!(EP::Model, inputs::Dict, setup::Dict)

	println("Discharge Module")

	dfGen = inputs["dfGen"]


	G = inputs["G"]     # Number of resources (generators, storage, DR, and DERs)
	T = inputs["T"]     # Number of time steps
	Z = inputs["Z"]     # Number of zones
	### Variables ###

	# Energy injected into the grid by resource "y" at hour "t"
	@variable(EP, vP[y=1:G,t=1:T] >=0);
	@variable(EP, vP_PureElectricity[y=1:G, t=1:T]>=0)
	@variable(EP, vP_ProcessHeat[y=1:G, t=1:T]>=0)


	##electricity revenues
	@expression(EP, eRevElectricity[y =1:G,t=1:T], (EP[:vP][y,t]*(inputs["LMP"][t])))
	@expression(EP, eTotalRevElectricityT[t = 1:T], sum(eRevElectricity[y, t] for y in 1:G))
	@expression(EP, eTotalRevElectricity, sum(eTotalRevElectricityT[t] for t in 1:T))

	EP[:eObj] -=  eTotalRevElectricity

	@expression(EP, eRevElectricity_ProcessHeat[y =1:G,t=1:T], (EP[:vP_ProcessHeat][y,t]*(inputs["LMP"][t])))
	# @expression(EP, eTotalRevElectricity_ProcessHeatT[t = 1:T], sum(eRevElectricity_ProcessHeat[y, t] for y in 1:G))
	# @expression(EP, eTotalRevElectricity_ProcessHeat, sum(eTotalRevElectricity_ProcessHeatT[t] for t in 1:T))


	@expression(EP, eRevElectricity_PureElectricity[y =1:G,t=1:T], (EP[:vP_PureElectricity][y,t]*(inputs["LMP"][t])))
	# @expression(EP, eTotalRevElectricity_PureElectricityT[t = 1:T], sum(eRevElectricity_PureElectricity[y, t] for y in 1:G))
	# @expression(EP, eTotalRevElectricity_PureElectricity, sum(eTotalRevElectricity_PureElectricityT[t] for t in 1:T))


	# EP[:eObj] -=  eTotalRevElectricity_ProcessHeat
	# EP[:eObj] -=  eTotalRevElectricity_PureElectricity

	# ### Expressions ###

	# ## Objective Function Expressions ##

	# # Variable costs of "generation" for resource "y" during hour "t" = variable O&M plus fuel cost

	# #Incorporates the PTC incentive if the IRA settings is set to 1.
	if setup["IRA"] == 1 && setup["PTC"] == 1
		@expression(EP, eCFuel_Electricity[y=1:G,t=1:T], (inputs["omega"][t]*(inputs["C_Fuel_per_MWh"][y,t]/dfGen[y,:Thermal_Efficiency])*vP[y,t]))
		@expression(EP, eCVarOM_Electricity[y=1:G,t=1:T], (inputs["omega"][t]*(dfGen[y,:VarOM])*vP[y,t]))
		@expression(EP, eCVar_out_Electricity[y=1:G,t=1:T], (eCVarOM_Electricity[y,t] + eCFuel_Electricity[y,t]))
	else
		@expression(EP, eCVar_out_Electricity[y=1:G,t=1:T], (inputs["omega"][t]*(dfGen[y,:VarOM]+inputs["C_Fuel_per_MWh"][y,t]/dfGen[y,:Thermal_Efficiency])*vP[y,t])) #this is the original line -Juan
	end
	
	# #@expression(EP, eCVar_out[y=1:G,t=1:T], (round(inputs["omega"][t]*(dfGen[y,:Var_OM_Cost_per_MWh]+inputs["C_Fuel_per_MWh"][y,t]), digits=RD)*vP[y,t]))
	# # Sum individual resource contributions to variable discharging costs to get total variable discharging costs
	
	
	@expression(EP, eTotalCVarOutT_Electricity[t=1:T], sum(eCVar_out_Electricity[y,t] for y in 1:G))
	@expression(EP, eTotalCVarOut_Electricity, sum(eTotalCVarOutT_Electricity[t] for t in 1:T))

	if setup["IRA"] == 1 && setup["PTC"] == 1

		@expression(EP, eTotalCFuelT_Electricity[t=1:T], sum(eCFuel_Electricity[y,t] for y in 1:G))
		@expression(EP, eTotalCFuel_Electricity, sum(eTotalCFuelT_Electricity[t] for t in 1:T))

		@expression(EP, eTotalCVarOMT_Electricity[t=1:T], sum(eCVarOM_Electricity[y,t] for y in 1:G))
		@expression(EP, eTotalCVarOM_Electricity, sum(eTotalCVarOMT_Electricity[t] for t in 1:T))


		#regional cost breakdown - Juan
		# @expression(EP, eTotalCProductionTaxCredit_Zone_Electricity[z=1:Z], sum(eCProductionTaxCredit_Electricity[y,t] for y=dfGen[findall(x->x==z,dfGen[!,"Zone"]),:R_ID], t = 1:T))
		@expression(EP, eTotalCFuel_Zone_Electricity[z=1:Z], sum(eCFuel_Electricity[y,t] for y=dfGen[findall(x->x==z,dfGen[!,"Zone"]),:R_ID], t = 1:T))
		@expression(EP, eTotalCVarOM_Zone_Electricity[z=1:Z], sum(eCVarOM_Electricity[y,t] for y=dfGen[findall(x->x==z,dfGen[!,"Zone"]),:R_ID], t = 1:T))
	end

	# Add total variable discharging cost contribution to the objective function
	EP[:eObj] += eTotalCVarOut_Electricity

	# # ESR Policy
	# if setup["EnergyShareRequirement"] >= 1

	# 	@expression(EP, eESRDischarge[ESR=1:inputs["nESR"]], sum(inputs["omega"][t]*dfGen[y,Symbol("ESR_$ESR")]*EP[:vP][y,t] for y=dfGen[findall(x->x>0,dfGen[!,Symbol("ESR_$ESR")]),:R_ID], t=1:T)
	# 					- sum(inputs["dfESR"][z,ESR]*inputs["omega"][t]*inputs["pD"][t,z] for t=1:T, z=findall(x->x>0,inputs["dfESR"][:,ESR])))

	# 	EP[:eESR] += eESRDischarge
	# end

end
