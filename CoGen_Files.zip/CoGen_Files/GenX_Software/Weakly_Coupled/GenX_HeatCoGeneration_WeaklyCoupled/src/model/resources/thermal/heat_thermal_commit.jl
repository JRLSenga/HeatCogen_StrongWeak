@doc raw"""
	thermal_commit!(EP::Model, inputs::Dict, setup::Dict)

This function defines the operations for producing heat alongside electricity
"""
function heat_thermal_commit!(EP::Model, inputs::Dict, setup::Dict)

	println("Thermal (Unit Commitment) Resources Module")

	dfGen = inputs["dfGen"]

	T = inputs["T"]     # Number of time steps (hours)
	Z = inputs["Z"]     # Number of zones
	G = inputs["G"]     # Number of resources

	p = inputs["hours_per_subperiod"] #total number of hours per subperiod

	THERM_COMMIT = inputs["THERM_COMMIT"]

	### Expressions ###

    # These variables are used in the ramp-up and ramp-down expressions
    reserves_term = @expression(EP, [y in THERM_COMMIT, t in 1:T], 0)
    regulation_term = @expression(EP, [y in THERM_COMMIT, t in 1:T], 0)

    if setup["Reserves"] > 0
        THERM_COMMIT_REG = intersect(THERM_COMMIT, inputs["REG"]) # Set of thermal resources with regulation reserves
        THERM_COMMIT_RSV = intersect(THERM_COMMIT, inputs["RSV"]) # Set of thermal resources with spinning reserves
        regulation_term = @expression(EP, [y in THERM_COMMIT, t in 1:T],
                           y ∈ THERM_COMMIT_REG ? EP[:vREG][y,t] - EP[:vREG][y, hoursbefore(p, t, 1)] : 0)
        reserves_term = @expression(EP, [y in THERM_COMMIT, t in 1:T],
                           y ∈ THERM_COMMIT_RSV ? EP[:vRSV][y,t] : 0)
    end

	## Power Balance Expressions ## #---Juan Senga (key addition)
	@expression(EP, ePowerBalanceThermCommit_Heat[t=1:T, z=1:Z],
		sum(EP[:vH_UsableProcessHeat][y,t] for y in intersect(THERM_COMMIT, dfGen[dfGen[!,:Zone].==z,:R_ID])))

	EP[:ePowerBalance_Heat] += ePowerBalanceThermCommit_Heat

	### Constraints ###

	# #Share of Thermal Power Available for Work w:
	# @expression(EP, w[y in THERM_COMMIT, t=1:T], (dfGen[y,:Thermal_Efficiency]*(dfGen[y,:Reactor_Temp] - setup["ProcessTemp"])/(dfGen[y,:Reactor_Temp] - dfGen[y,:Condenser_Temp]))*(inputs["pP_Max"][y,t]*dfGen[y,:Cap_Size]*EP[:vCOMMIT_HEAT][y,t])


	# #Available Share of Thermal z:
	# @expression(EP, avail_cap_thermal[y in THERM_COMMIT, t = 1:T],  inputs["pP_Max"][y,t]*dfGen[y,:Cap_Size]*EP[:vCOMMIT_HEAT][y,t] - EP[:vH][y,t])

	# #Elec = Min(w, z) + max(z-w, 0)*eta
	# #calculating the Strong Cogen Electricity
	# @variable(EP, vMin_Elec[y in THERM_COMMIT, t=1:T] >=0);
	# @constraint(EP, cMinPortionOfFormula_A[y in THERM_COMMIT, t = 1:T], vMin_Elec[y, t] <= EP[:w][y, t])
	# @constraint(EP, cMinPortionOfFormula_B[y in THERM_COMMIT, t = 1:T], vMin_Elec[y, t] <= EP[:avail_cap_thermal][y])




	#max(z-w, 0)*eta*vCOMMIT_HEAT

	#if z< w, 




	@constraint(EP, cIndustryPlusPureElectricityEqualsHeatProduced[y in THERM_COMMIT, t= 1:T], EP[:vH_Industrial][y, t] + EP[:vH_PureElectricity][y, t] <= EP[:vH][y, t])

	@constraint(EP, cElectfromProcessAndElectPureEqualsTotalElect[y in THERM_COMMIT, t= 1:T], EP[:vP_PureElectricity][y, t] == EP[:vP][y, t])

	### Industrial Heat must be less than or equal to Reactor Heat #---Juan Senga (key addition)
	@constraint(EP, cIndustrialHeatLessReactorOutput[y in THERM_COMMIT, t = 1:T], EP[:vH_UsableProcessHeat][y,t] == EP[:vH_Industrial][y, t]) #

	# @constraint(EP, cElectricityOutput_Process[y in THERM_COMMIT, t = 1:T], EP[:vP_ProcessHeat][y, t] <= EP[:vH_Industrial][y, t]*((dfGen[y,:Reactor_Temp] - setup["ProcessTemp"])/(dfGen[y,:Reactor_Temp] - dfGen[y,:Condenser_Temp])))

	@constraint(EP, cElectricityOutput_Pure[y in THERM_COMMIT, t=1:T], EP[:vP_PureElectricity][y, t] <= EP[:vH_PureElectricity][y, t]*dfGen[y,:Thermal_Efficiency])

	### Capacitated limits on unit commitment decision variables (Constraints #1-3)
	@constraints(EP, begin
		[y in THERM_COMMIT, t=1:T], EP[:vCOMMIT_HEAT][y,t] <= EP[:eTotalCap][y]/dfGen[y,:Cap_Size]
		[y in THERM_COMMIT, t=1:T], EP[:vSTART_HEAT][y,t] <= EP[:eTotalCap][y]/dfGen[y,:Cap_Size]
		[y in THERM_COMMIT, t=1:T], EP[:vSHUT_HEAT][y,t] <= EP[:eTotalCap][y]/dfGen[y,:Cap_Size]
	end)

	# Commitment state constraint linking startup and shutdown decisions (Constraint #4)
	@constraints(EP, begin
		[y in THERM_COMMIT, t in 1:T], EP[:vCOMMIT_HEAT][y,t] == EP[:vCOMMIT_HEAT][y, hoursbefore(p, t, 1)] + EP[:vSTART_HEAT][y,t] - EP[:vSHUT_HEAT][y,t]
	end)

	### Maximum ramp up and down between consecutive hours (Constraints #5-6)

	## For Start Hours
	# Links last time step with first time step, ensuring position in hour 1 is within eligible ramp of final hour position
	# rampup constraints
	@constraint(EP,[y in THERM_COMMIT, t in 1:T],
               EP[:vH][y,t] - EP[:vH][y, hoursbefore(p, t, 1)] + regulation_term[y,t] + reserves_term[y,t] <= dfGen[y,:Ramp_Up_Percentage_Thermal]*dfGen[y,:Cap_Size]*(EP[:vCOMMIT_HEAT][y,t]-EP[:vSTART_HEAT][y,t])
			+ min(inputs["pP_Max"][y,t],max(dfGen[y,:Min_Power_Thermal],dfGen[y,:Ramp_Up_Percentage_Thermal]))*dfGen[y,:Cap_Size]*EP[:vSTART_HEAT][y,t]
			- dfGen[y,:Min_Power_Thermal]*dfGen[y,:Cap_Size]*EP[:vSHUT_HEAT][y,t])

	# rampdown constraints
	@constraint(EP,[y in THERM_COMMIT, t in 1:T],
               EP[:vH][y, hoursbefore(p,t,1)] - EP[:vH][y,t] - regulation_term[y,t] + reserves_term[y, hoursbefore(p,t,1)] <= dfGen[y,:Ramp_Dn_Percentage_Thermal]*dfGen[y,:Cap_Size]*(EP[:vCOMMIT_HEAT][y,t]-EP[:vSTART_HEAT][y,t])
			- dfGen[y,:Min_Power_Thermal]*dfGen[y,:Cap_Size]*EP[:vSTART_HEAT][y,t]
			+ min(inputs["pP_Max"][y,t],max(dfGen[y,:Min_Power_Thermal],dfGen[y,:Ramp_Dn_Percentage_Thermal]))*dfGen[y,:Cap_Size]*EP[:vSHUT_HEAT][y,t])


	### Minimum and maximum power output constraints (Constraints #7-8)
	if setup["Reserves"] == 1
		# If modeling with regulation and reserves, constraints are established by thermal_commit_reserves() function below
		thermal_commit_reserves!(EP, inputs)
	else
		@constraints(EP, begin
			# Minimum stable power generated per technology "y" at hour "t" > Min power
			[y in THERM_COMMIT, t=1:T], EP[:vH][y,t] >= dfGen[y,:Min_Power_Thermal]*dfGen[y,:Cap_Size]*EP[:vCOMMIT_HEAT][y,t]

			# Maximum power generated per technology "y" at hour "t" < Max power
			[y in THERM_COMMIT, t=1:T], EP[:vH][y,t] <= inputs["pP_Max"][y,t]*dfGen[y,:Cap_Size]*EP[:vCOMMIT_HEAT][y,t]
		end)
	end

	### Minimum up and down times (Constraints #9-10)
	Up_Time_Thermal = zeros(Int, nrow(dfGen))
	Up_Time_Thermal[THERM_COMMIT] .= Int.(floor.(dfGen[THERM_COMMIT,:Up_Time_Thermal]))
	@constraint(EP, [y in THERM_COMMIT, t in 1:T],
			EP[:vCOMMIT_HEAT][y,t] >= sum(EP[:vSTART_HEAT][y, u] for u in hoursbefore(p, t, 0:(Up_Time_Thermal[y] - 1)))
	)

	Down_Time_Thermal = zeros(Int, nrow(dfGen))
	Down_Time_Thermal[THERM_COMMIT] .= Int.(floor.(dfGen[THERM_COMMIT,:Down_Time_Thermal]))
	@constraint(EP, [y in THERM_COMMIT, t in 1:T],
			EP[:eTotalCap][y]/dfGen[y,:Cap_Size]-EP[:vCOMMIT_HEAT][y,t] >= sum(EP[:vSHUT_HEAT][y, u] for u in hoursbefore(p, t, 0:(Down_Time_Thermal[y] - 1)))
	)

	## END Constraints for thermal units subject to integer (discrete) unit commitment decisions
	
	

end



