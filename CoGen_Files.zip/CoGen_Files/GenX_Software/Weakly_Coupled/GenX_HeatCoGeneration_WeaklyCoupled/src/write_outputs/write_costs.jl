@doc raw"""
	write_costs(path::AbstractString, inputs::Dict, setup::Dict, EP::Model)

Function for writing the costs pertaining to the objective function (fixed, variable O&M etc.).
"""
function write_costs(path::AbstractString, inputs::Dict, setup::Dict, EP::Model)
	## Cost results
	dfGen = inputs["dfGen"]
	SEG = inputs["SEG"]  # Number of lines
	Z = inputs["Z"]     # Number of zones
	T = inputs["T"]     # Number of time steps (hours)

	dfCost = DataFrame(Costs = ["cTotal", "cFix", "cVar", "cNSE", "cStart", "cUnmetRsv", "cNetworkExp", "cUnmetPolicyPenalty", "cCCS_Incentive", "cProductionTaxCredit", "cFuel", "cVarOM", "cFixedOMDischarge", "cInvCostDischarge", "cTaxCredit","cFixedOMEnergy", "cInvCostEnergy", "cTaxCreditEnergy","RevElectricity","cFuel_Elec", "cVarOM_Elec"])
	cVar = value(EP[:eTotalCVarOut])+ value(EP[:eTotalCVarOut_Electricity])+  (!isempty(inputs["STOR_ALL"]) ? value(EP[:eTotalCVarIn]) : 0.0) + (!isempty(inputs["FLEX"]) ? value(EP[:eTotalCVarFlexIn]) : 0.0)
	cFix = value(EP[:eTotalCFix]) + (!isempty(inputs["STOR_ALL"]) ? value(EP[:eTotalCFixEnergy]) : 0.0) + (!isempty(inputs["STOR_ASYMMETRIC"]) ? value(EP[:eTotalCFixCharge]) : 0.0)
	
	#cost outputs were changed to look at the IRA specific items. --Juan
	
	if setup["IRA"] == 1
		#original # dfCost[!,Symbol("Total")] = [value(EP[:eObj]), cFix, cVar, value(EP[:eTotalCNSE]), 0.0, 0.0, 0.0, 0.0, -1*value(EP[:eTotalCCO2CaptureIncentive]),-1*value(EP[:eTotalCProductionTaxCredit]),value(EP[:eTotalCFuel]),value(EP[:eTotalCVarOM]), value(EP[:eTotalCFixedOM]), value(EP[:eTotalCInv]),-1*value(EP[:eTotalCInvTaxCredit]),value(EP[:eTotalCFixOMEnergy]),value(EP[:eTotalCInvMWh]),-1*value(EP[:eTotalCInvTaxCreditMWh])] 
		dfCost[!,Symbol("Total")] = [value(EP[:eObj]), cFix, cVar, value(EP[:eTotalCNSE]), 0.0, 0.0, 0.0, 0.0, -1*value(EP[:eTotalCCO2CaptureIncentive]),0.0,value(EP[:eTotalCFuel]),value(EP[:eTotalCVarOM]), value(EP[:eTotalCFixedOM]), value(EP[:eTotalCInv]),0.0,0.0,0.0,0.0, value(EP[:eTotalRevElectricity]),value(EP[:eTotalCFuel_Electricity]),value(EP[:eTotalCVarOM_Electricity])] 
	else
		dfCost[!,Symbol("Total")] = [value(EP[:eObj]), cFix, cVar, value(EP[:eTotalCNSE]), 0.0, 0.0, 0.0, 0.0] 

	end
	
	if setup["ParameterScale"] == 1
		dfCost.Total *= ModelScalingFactor^2
	end

	if setup["UCommit"]>=1
		dfCost[5,2] = value(EP[:eTotalCStart_HEAT])
	end

	if setup["Reserves"]==1
		dfCost[6,2] = value(EP[:eTotalCRsvPen])
	end

	if setup["NetworkExpansion"] == 1 && Z > 1
		dfCost[7,2] = value(EP[:eTotalCNetworkExp])
	end

	if haskey(inputs, "dfCapRes_slack")
		dfCost[8,2] += value(EP[:eCTotalCapResSlack])
	end

	if haskey(inputs, "dfESR_slack")
		dfCost[8,2] += value(EP[:eCTotalESRSlack])
	end
	
	if haskey(inputs, "dfCO2Cap_slack")
		dfCost[8,2] += value(EP[:eCTotalCO2CapSlack])
	end
	
	if haskey(inputs, "MinCapPriceCap")
		dfCost[8,2] += value(EP[:eTotalCMinCapSlack])
	end	

	if setup["ParameterScale"] == 1
		dfCost[5,2] *= ModelScalingFactor^2
		dfCost[6,2] *= ModelScalingFactor^2
		dfCost[7,2] *= ModelScalingFactor^2
		dfCost[8,2] *= ModelScalingFactor^2
		dfCost[9,2] *= ModelScalingFactor^2
	end

	for z in 1:Z
		tempCTotal = 0.0
		tempCFix = 0.0
		tempCVar = 0.0
		tempCStart = 0.0
		tempCNSE = 0.0
		tempCCCS_Incentive = 0.0
		tempCPTC = 0.0
		tempCFuel = 0.0
		tempCVarOM = 0.0
		tempCFixedOMDischarge = 0.0
		tempCInvCostDischarge = 0.0
		tempCTaxCredit = 0.0
		tempCFixedOMEnergy = 0.0
		tempCInvCostEnergy = 0.0
		tempCTaxCreditEnergy = 0.0
		tempRevElectricity = 0.0
		tempFuelElectricity = 0.0
		tempVarElectricity = 0.0
	

		# "cCCS_Incentive", "cProductionTaxCredit", "cFuel", "cVarOM", "cFixedOMDischarge", "cInvCostDischarge", "cTaxCredit","cFixedOMEnergy", "cInvCostEnergy", "cTaxCreditEnergy"

		Y_ZONE = dfGen[dfGen[!,:Zone].==z,:R_ID]
		STOR_ALL_ZONE = intersect(inputs["STOR_ALL"], Y_ZONE)
		STOR_ASYMMETRIC_ZONE = intersect(inputs["STOR_ASYMMETRIC"], Y_ZONE)
		FLEX_ZONE = intersect(inputs["FLEX"], Y_ZONE)
		COMMIT_ZONE = intersect(inputs["COMMIT"], Y_ZONE)

		eCFix = sum(value.(EP[:eCFix][Y_ZONE]))
		tempCFix += eCFix
		tempCTotal += eCFix

		tempCVar = sum(value.(EP[:eCVar_out][Y_ZONE,:]))
		tempCTotal += tempCVar

		if !isempty(STOR_ALL_ZONE)
			eCVar_in = sum(value.(EP[:eCVar_in][STOR_ALL_ZONE,:]))
			tempCVar += eCVar_in
			eCFixEnergy = sum(value.(EP[:eCFixEnergy][STOR_ALL_ZONE]))
			tempCFix += eCFixEnergy

			tempCTotal += eCVar_in + eCFixEnergy
		end
		if !isempty(STOR_ASYMMETRIC_ZONE)
			eCFixCharge = sum(value.(EP[:eCFixCharge][STOR_ASYMMETRIC_ZONE]))
			tempCFix += eCFixCharge
			tempCTotal += eCFixCharge
		end
		if !isempty(FLEX_ZONE)
			eCVarFlex_in = sum(value.(EP[:eCVarFlex_in][FLEX_ZONE,:]))
			tempCVar += eCVarFlex_in
			tempCTotal += eCVarFlex_in
		end

		if setup["UCommit"] >= 1 && !isempty(COMMIT_ZONE)
			eCStart_HEAT = sum(value.(EP[:eCStart_HEAT][COMMIT_ZONE,:]))
			tempCStart += eCStart_HEAT
			tempCTotal += eCStart_HEAT
		end

		tempCNSE = sum(value.(EP[:eCNSE][:,:,z]))
		# tempCCCS_Incentive  = -1*sum(value.(EP[:eTotalCCO2CaptureIncentive_Zone][z]))
		# tempCPTC = -1*sum(value.(EP[:eTotalCProductionTaxCredit_Zone][z]))
		tempCFuel = sum(value.(EP[:eTotalCFuel_Zone][z]))
		tempCVarOM = sum(value.(EP[:eTotalCVarOM_Zone][z]))


		tempCCCS_Incentive  = 0.0
		tempCPTC =0.0





		println("AYYY ", z, tempCPTC, tempCFuel, tempCVarOM)

		tempCFixedOMDischarge = sum(value.(EP[:eTotalCFixedOM_Zone][z]))
		tempCInvCostDischarge = sum(value.(EP[:eTotalCInv_Zone][z]))
		tempCTaxCredit = -1*sum(value.(EP[:eTotalCInvTaxCredit_Zone][z]))

		# tempCFixedOMEnergy = sum(value.(EP[:eTotalCFixOMEnergy_Zone][z]))
		# tempCInvCostEnergy = sum(value.(EP[:eTotalCInvMWh_Zone][z]))
		# tempCTaxCreditEnergy = -1*sum(value.(EP[:eTotalCInvTaxCreditMWh_Zone][z]))


		tempCFixedOMEnergy = 0.0
		tempCInvCostEnergy = 0.0
		tempCTaxCreditEnergy = 0.0

		tempCTotal += tempCNSE
	


		# -1*value(EP[:eTotalCCO2CaptureIncentive]),-1*value(EP[:eTotalCProductionTaxCredit]),value(EP[:eTotalCFuel]),value(EP[:eTotalCVarOM]), value(EP[:eTotalCFixedOM]), value(EP[:eTotalCInv]),-1*value(EP[:eTotalCInvTaxCredit]),value(EP[:eTotalCFixOMEnergy]),value(EP[:eTotalCInvMWh]),-1*value(EP[:eTotalCInvTaxCreditMWh])] 

		if setup["ParameterScale"] == 1
			tempCTotal *= ModelScalingFactor^2
			tempCFix *= ModelScalingFactor^2
			tempCVar *= ModelScalingFactor^2
			tempCNSE *= ModelScalingFactor^2
			tempCStart *= ModelScalingFactor^2
		end
		# dfCost[!,Symbol("Zone$z")] = [tempCTotal, tempCFix, tempCVar, tempCNSE, tempCStart, "-", "-", "-",tempCCCS_Incentive ,tempCPTC,tempCFuel,tempCVarOM,tempCFixedOMDischarge,tempCInvCostDischarge,tempCTaxCredit,tempCFixedOMEnergy,tempCInvCostEnergy,tempCTaxCreditEnergy]
		dfCost[!,Symbol("Zone$z")] = [tempCTotal, tempCFix, tempCVar, tempCNSE, tempCStart, "-", "-", "-",tempCCCS_Incentive ,tempCPTC,tempCFuel,tempCVarOM,tempCFixedOMDischarge,tempCInvCostDischarge,tempCTaxCredit,tempCFixedOMEnergy,tempCInvCostEnergy,tempCTaxCreditEnergy, tempRevElectricity,tempFuelElectricity,tempVarElectricity]

		# dfCost[!,Symbol("Zone$z")] = [tempCTotal, tempCFix, tempCVar, tempCNSE, tempCStart, "-", "-", "-","-" ,"-","-","-","-","-","-","-","-","-"]
	end
	CSV.write(joinpath(path, "costs.csv"), dfCost)

	return value(EP[:eObj])
end
