@doc raw"""
	load_load_data!(setup::Dict, path::AbstractString, inputs::Dict)

Read input parameters related to LMPs
"""
function load_LMP_data!(setup::Dict, path::AbstractString, inputs::Dict)

	# Load related inputs
	data_directory = joinpath(path, setup["TimeDomainReductionFolder"])
    if setup["TimeDomainReduction"] == 1  && time_domain_reduced_files_exist(data_directory)
        my_dir = data_directory
	else
        my_dir = path
	end
    filename = "ElectricityPrice_Zero_data.csv"
    LMP_in = load_dataframe(joinpath(my_dir, filename))

    as_vector(col::Symbol) = collect(skipmissing(LMP_in[!, col]))

	# Number of time steps (periods)
    T = length(as_vector(:Time_Index))
	


	## Set indices for internal use
    inputs["T"] = T

	Z = inputs["Z"]   # Number of zones



	
	
	start = findall(s -> s == "LMP", names(LMP_in))[1] #gets the starting column number of all the columns, with header "Load_MW_z1"
    
    
   
    # Demand in MW
    inputs["LMP"] =Matrix(LMP_in[1:T, start:start+Z-1])



	println(filename * " Successfully Read!")
end





