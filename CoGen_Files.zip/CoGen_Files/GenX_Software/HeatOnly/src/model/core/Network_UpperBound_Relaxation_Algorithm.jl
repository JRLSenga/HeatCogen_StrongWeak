
function network_upperbound_relaxation_algo_transmission_dual(inputs::Dict, path::AbstractString)

    L = inputs["L"]     # Number of transmission lines
	R = inputs["R"]		# Number of Regions

    REGIONS_FROM = inputs["Regions_From"]
    REGIONS_TO = inputs["Regions_To"]

    filename_transmission_dual = "transmission_dual.csv"


    dfTransmission = load_dataframe(joinpath(path, filename_transmission_dual))
    
    Minimum_Interregional = inputs["Minimum_Interregional_Transfer"]
    dfTransmission = insertcols!(dfTransmission, 3, :Regions_From => inputs["Regions_From"])
    dfTransmission = insertcols!(dfTransmission, 4, :Regions_To => inputs["Regions_To"])


    
    dfTransmission = insertcols!(dfTransmission, 5, :Diff_Region => inputs["Diff_Region"])

    delta = Float64[]
    delta = ones(R)
    delta_star = findmax(delta)

    println(dfTransmission)

    # Lines_to_from_region = findall(((dfTransmission[!,"Regions_From"].==delta_star[2] && dfTransmission[!, "Diff_Region"].==true) || (dfTransmission[!,"Regions_To"].==delta_star[2] && dfTransmission[!, "Diff_Region"].==true)) && )
    
    # exit()

    # MaxLineReinforcement_copy = copy(inputs["pMax_Line_Reinforcement"])
    Unincluded_Region = 11
    while delta_star[1] > 0
        delta = Float64[]
        delta = ones(R)
        delta_star = findmax(delta) 
        MaxLineReinforcement_copy = copy(inputs["pMax_Line_Reinforcement"]) #-- original
        for r in 1:R
            MaxTrans_region = sum(inputs["pTrans_Max"][l] + inputs["pMax_Line_Reinforcement"][l] for l=1:L if REGIONS_FROM[l] == r && REGIONS_FROM[l] != REGIONS_TO[l] && REGIONS_FROM[l] != Unincluded_Region  && REGIONS_TO[l] != Unincluded_Region; init=0) + sum(inputs["pTrans_Max"][l] + inputs["pMax_Line_Reinforcement"][l] for l=1:L if REGIONS_TO[l] == r && REGIONS_FROM[l] != REGIONS_TO[l] && REGIONS_FROM[l] != Unincluded_Region  && REGIONS_TO[l] != Unincluded_Region; init=0)
            delta[r] =  max(inputs["Minimum_Interregional_Transfer"][r]-MaxTrans_region, 0)
        end
        
        #tuple: (delta value, region number)
        delta_star = findmax(delta)
        println(delta_star)
        if delta_star[1] > 0

        

            for l in 1:L
                #gets the lines that go to and from the region with the largest gap between MITC and current transfer capacity
                Lines_to_from_region = filter(x->(((x.Regions_To == delta_star[2] && x.Diff_Region == true) || (x.Regions_From == delta_star[2] && x.Diff_Region == true)) && ((x.Regions_From != Unincluded_Region) && (x.Regions_To != Unincluded_Region))), dfTransmission)
                
                if nrow(Lines_to_from_region) > 0
                    total_dual = sum(Lines_to_from_region[!, "Value"])
        
                end

                current_transmission = sum(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l] for l=1:L if REGIONS_FROM[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l] && REGIONS_FROM[l] != Unincluded_Region  && REGIONS_TO[l] != Unincluded_Region; init=0) + sum(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l] for l=1:L if REGIONS_TO[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l] && REGIONS_FROM[l] != Unincluded_Region  && REGIONS_TO[l] != Unincluded_Region; init=0) ## -new
                if ((REGIONS_FROM[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l]) || (REGIONS_TO[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l])) && (REGIONS_FROM[l] != Unincluded_Region) && (REGIONS_TO[l] != Unincluded_Region)
                    dfLine = filter(x->(x.dim1 == l), Lines_to_from_region)
                    print(Lines_to_from_region)
                    println(dfLine, delta_star[2])
                    # if nrow(dfLine) > 0
                    inputs["pMax_Line_Reinforcement"][l] = inputs["pMax_Line_Reinforcement"][l] + delta_star[1]*(dfLine[1, "Value"])/total_dual
                    print(inputs["pMax_Line_Reinforcement"][l])
                    # end
                end
            end
        
        end



        #  inputs_nw["pC_Line_Reinforcement"]
        println("TEST ALGO", delta_star)
        println(delta)
        println(inputs["Minimum_Interregional_Transfer"])
        print(inputs["pMax_Line_Reinforcement"])
    end

    # exit()
    
    Final_Max_Reinforcement = copy(inputs["pMax_Line_Reinforcement"])

    println("Max Line Reinforcement Parameters Set!")


    return Final_Max_Reinforcement
end

function transmission_dual_algorithm(inputs_nw::Dict, path::AbstractString)#, iteration_dual::Integer)

    L = inputs_nw["L"]     # Number of transmission lines
	R = inputs_nw["R"]		# Number of Regions

    #for transmission dual algorithm. This is the start of the test - Juan
    filename_transmission_dual = "transmission_dual.csv"


    dfTransmission = load_dataframe(joinpath(path, filename_transmission_dual))
    
    Minimum_Interregional = inputs_nw["Minimum_Interregional_Transfer"]
    dfTransmission = insertcols!(dfTransmission, 3, :Regions_From => inputs_nw["Regions_From"])
    dfTransmission = insertcols!(dfTransmission, 4, :Regions_To => inputs_nw["Regions_To"])
    dfTransmission = insertcols!(dfTransmission, 5, :Diff_Region => inputs_nw["Diff_Region"])

    REGIONS_FROM = inputs_nw["Regions_From"]
    REGIONS_TO = inputs_nw["Regions_To"]

    #process input for how large each iteration increases the maximum line reinforcement (the lower the increase, the more accurate the results are. i.e. if the increase is epsilon MW each time)
    max_line_increase = 3000


    
    #calculate the maximum remaining requirement that needs to be allocated to a max line reinforcement parameter
    delta = Float64[]
    delta = ones(R)
    delta_star = findmax(delta)

    Unincluded_Region = 11
    for r in 1:R
        MaxTrans_region = sum(inputs_nw["pTrans_Max"][l] + inputs_nw["pMax_Line_Reinforcement"][l] for l=1:L if REGIONS_FROM[l] == r && REGIONS_FROM[l] != REGIONS_TO[l] && REGIONS_FROM[l] != Unincluded_Region  && REGIONS_TO[l] != Unincluded_Region; init=0) + sum(inputs_nw["pTrans_Max"][l] + inputs_nw["pMax_Line_Reinforcement"][l] for l=1:L if REGIONS_TO[l] == r && REGIONS_FROM[l] != REGIONS_TO[l] && REGIONS_FROM[l] != Unincluded_Region  && REGIONS_TO[l] != Unincluded_Region; init=0)
        delta[r] =  max(inputs_nw["Minimum_Interregional_Transfer"][r]-MaxTrans_region, 0)
    end

    println(delta)

    #get the lines that are to and from different regions
    Lines_Different_Regions = findall(dfTransmission[!,"Diff_Region"].==true)


    #filter the lines that still have a positive remaining minimum requirement, and that is not texas
    Lines_Positive_Remaining_Min_Requirement = filter(x->(((delta[x.Regions_From] > 0) ||(delta[x.Regions_To] > 0)) && (x.dim1 in Lines_Different_Regions) && ((x.Regions_From != Unincluded_Region) && (x.Regions_To != Unincluded_Region))), dfTransmission)
    print(Lines_Positive_Remaining_Min_Requirement)

    

    if nrow(Lines_Positive_Remaining_Min_Requirement) > 0

        
        MinimumDual = findfirst(==(minimum(Lines_Positive_Remaining_Min_Requirement.Value)), Lines_Positive_Remaining_Min_Requirement.Value)
        MinimumDual_RegionFrom = Lines_Positive_Remaining_Min_Requirement[MinimumDual, "Regions_From"]
        MinimumDual_RegionTo = Lines_Positive_Remaining_Min_Requirement[MinimumDual, "Regions_To"]
        MinimumDual_LineNumber = Lines_Positive_Remaining_Min_Requirement[MinimumDual, "dim1"]

        println(nrow(Lines_Positive_Remaining_Min_Requirement))

        println("AYY", MinimumDual_LineNumber, Lines_Positive_Remaining_Min_Requirement[MinimumDual, "Value"])
        
        inputs_nw["pMax_Line_Reinforcement"][MinimumDual_LineNumber] += min(max_line_increase, max(delta[MinimumDual_RegionFrom], delta[MinimumDual_RegionTo]))
        return 1 #1 meaning still need to iterate
    else
        return 0 #0 meaning don't need to iterate. Can output already(?)
    end



    
    # exit()
    #END OF transmission dual test - Juan

end

#scaling is based on existing transmission
function network_upperbound_relaxation_algo_existingtrans(inputs::Dict)

    L = inputs["L"]     # Number of transmission lines
	R = inputs["R"]		# Number of Regions

    REGIONS_FROM = inputs["Regions_From"]
    REGIONS_TO = inputs["Regions_To"]

    delta = Float64[]
    delta = ones(R)
    delta_star = findmax(delta)

    # MaxLineReinforcement_copy = copy(inputs["pMax_Line_Reinforcement"])
    while delta_star[1] > 0
        delta = Float64[]
        delta = ones(R)
        delta_star = findmax(delta) 
        MaxLineReinforcement_copy = copy(inputs["pMax_Line_Reinforcement"]) #-- original
        for r in 1:R
            MaxTrans_region = sum(inputs["pTrans_Max"][l] + inputs["pMax_Line_Reinforcement"][l] for l=1:L if REGIONS_FROM[l] == r && REGIONS_FROM[l] != REGIONS_TO[l]; init=0) + sum(inputs["pTrans_Max"][l] + inputs["pMax_Line_Reinforcement"][l] for l=1:L if REGIONS_TO[l] == r && REGIONS_FROM[l] != REGIONS_TO[l]; init=0)
            delta[r] =  max(inputs["Minimum_Interregional_Transfer"][r]-MaxTrans_region, 0)
        end
        
        #tuple: (delta value, region number)
        delta_star = findmax(delta)
        println(delta_star)
        if delta_star[1] > 0


            for l in 1:L
                current_transmission = sum(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l] for l=1:L if REGIONS_FROM[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l]; init=0) + sum(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l] for l=1:L if REGIONS_TO[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l]; init=0) ## -new
                if (REGIONS_FROM[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l]) || (REGIONS_TO[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l]) 
                    
                    inputs["pMax_Line_Reinforcement"][l] = inputs["pMax_Line_Reinforcement"][l] + delta_star[1]*(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l])/current_transmission # -new
                    # inputs["pMax_Line_Reinforcement"][l] = inputs["pMax_Line_Reinforcement"][l] + delta_star[1]*(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l])/delta_star[1] #- previous    
                    # inputs["pMax_Line_Reinforcement"][l] = inputs["pMax_Line_Reinforcement"][l] + delta_star[1]*(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l])/delta_star[1]
                end
            end

        end



        #  inputs_nw["pC_Line_Reinforcement"]
        println("TEST ALGO", delta_star)
        println(delta)
        println(inputs["Minimum_Interregional_Transfer"])

    end
    
    Final_Max_Reinforcement = copy(inputs["pMax_Line_Reinforcement"])

    println("Max Line Reinforcement Parameters Set!")


    return Final_Max_Reinforcement
end

function network_upperbound_relaxation_algo_existingtrans_withoutTexas(inputs::Dict)

    L = inputs["L"]     # Number of transmission lines
	R = inputs["R"]		# Number of Regions

    REGIONS_FROM = inputs["Regions_From"]
    REGIONS_TO = inputs["Regions_To"]

    delta = Float64[]
    delta = ones(R)
    delta_star = findmax(delta)

    # MaxLineReinforcement_copy = copy(inputs["pMax_Line_Reinforcement"])
    Unincluded_Region = 11
    while delta_star[1] > 0
        delta = Float64[]
        delta = ones(R)
        delta_star = findmax(delta) 
        MaxLineReinforcement_copy = copy(inputs["pMax_Line_Reinforcement"]) #-- original
        for r in 1:R
            MaxTrans_region = sum(inputs["pTrans_Max"][l] + inputs["pMax_Line_Reinforcement"][l] for l=1:L if REGIONS_FROM[l] == r && REGIONS_FROM[l] != REGIONS_TO[l] && REGIONS_FROM[l] != Unincluded_Region  && REGIONS_TO[l] != Unincluded_Region; init=0) + sum(inputs["pTrans_Max"][l] + inputs["pMax_Line_Reinforcement"][l] for l=1:L if REGIONS_TO[l] == r && REGIONS_FROM[l] != REGIONS_TO[l]&& REGIONS_FROM[l] != Unincluded_Region  && REGIONS_TO[l] != Unincluded_Region; init=0)
            delta[r] =  max(inputs["Minimum_Interregional_Transfer"][r]-MaxTrans_region, 0)
        end
        
        #tuple: (delta value, region number)
        delta_star = findmax(delta)
        println(delta_star)
        if delta_star[1] > 0


            for l in 1:L
                current_transmission = sum(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l] for l=1:L if REGIONS_FROM[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l] && REGIONS_FROM[l] != Unincluded_Region  && REGIONS_TO[l] != Unincluded_Region; init=0) + sum(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l] for l=1:L if REGIONS_TO[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l] && REGIONS_FROM[l] != Unincluded_Region  && REGIONS_TO[l] != Unincluded_Region; init=0) ## -new
                if ((REGIONS_FROM[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l]) || (REGIONS_TO[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l]))  && (REGIONS_FROM[l] != Unincluded_Region) && (REGIONS_TO[l] != Unincluded_Region)
                    
                    inputs["pMax_Line_Reinforcement"][l] = inputs["pMax_Line_Reinforcement"][l] + delta_star[1]*(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l])/current_transmission # -new
                    # inputs["pMax_Line_Reinforcement"][l] = inputs["pMax_Line_Reinforcement"][l] + delta_star[1]*(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l])/delta_star[1] #- previous    
                    # inputs["pMax_Line_Reinforcement"][l] = inputs["pMax_Line_Reinforcement"][l] + delta_star[1]*(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l])/delta_star[1]
                end
            end

        end



        #  inputs_nw["pC_Line_Reinforcement"]
        println("TEST ALGO", delta_star)
        println(delta)
        println(inputs["Minimum_Interregional_Transfer"])

    end
    
    Final_Max_Reinforcement = copy(inputs["pMax_Line_Reinforcement"])

    println("Max Line Reinforcement Parameters Set!")


    return Final_Max_Reinforcement
end

#scaling is based on cost
function network_upperbound_relaxation_algo_costtobuild(inputs::Dict)

    L = inputs["L"]     # Number of transmission lines
	R = inputs["R"]		# Number of Regions

    REGIONS_FROM = inputs["Regions_From"]
    REGIONS_TO = inputs["Regions_To"]

    delta = Float64[]
    delta = ones(R)
    delta_star = findmax(delta)
    while delta_star[1] > 0
        delta = Float64[]
        delta = ones(R)
        delta_star = findmax(delta)
        MaxLineReinforcement_copy = copy(inputs["pMax_Line_Reinforcement"])
        for r in 1:R
            MaxTrans_region = sum(inputs["pTrans_Max"][l] + inputs["pMax_Line_Reinforcement"][l] for l=1:L if REGIONS_FROM[l] == r && REGIONS_FROM[l] != REGIONS_TO[l]; init=0) + sum(inputs["pTrans_Max"][l] + inputs["pMax_Line_Reinforcement"][l] for l=1:L if REGIONS_TO[l] == r && REGIONS_FROM[l] != REGIONS_TO[l]; init=0)
            delta[r] =  max(inputs["Minimum_Interregional_Transfer"][r]-MaxTrans_region, 0)
        end
        
        #tuple: (delta value, region number)
        delta_star = findmax(delta)
        println(delta_star)
        if delta_star[1] > 0


            for l in 1:L
                if (REGIONS_FROM[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l]) || (REGIONS_TO[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l]) 
                    inputs["pMax_Line_Reinforcement"][l] = inputs["pMax_Line_Reinforcement"][l] + delta_star[1]*(1.0/inputs["pC_Line_Reinforcement"][l])/(sum(1.0/inputs["pC_Line_Reinforcement"][l] for l=1:L  if REGIONS_FROM[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l]; init=0) + sum(1.0/inputs["pC_Line_Reinforcement"][l] for l=1:L  if REGIONS_TO[l] == delta_star[2] && REGIONS_FROM[l] != REGIONS_TO[l]; init=0))

                    # inputs["pMax_Line_Reinforcement"][l] = inputs["pMax_Line_Reinforcement"][l] + delta_star[1]*(inputs["pTrans_Max"][l] + MaxLineReinforcement_copy[l])/delta_star[1]
                end
            end

        end



        #  inputs_nw["pC_Line_Reinforcement"]
        println("TEST ALGO", delta_star)
        println(delta)
        println(inputs["Minimum_Interregional_Transfer"])

    end
    
    Final_Max_Reinforcement = copy(inputs["pMax_Line_Reinforcement"])

    println("Max Line Reinforcement Parameters Set!")


    return Final_Max_Reinforcement
end