@doc raw"""
	write_nse(path::AbstractString, inputs::Dict, setup::Dict, EP::Model)

Function for reporting non-served energy for every model zone, time step and cost-segment.
"""
function write_nse_montecarlo(path::AbstractString, inputs::Dict, setup::Dict, EP::Model, i::Int64)

	filename_affected_zones = "affected_zones.csv"
	montecarlo_output_path = joinpath(pwd(), "MonteCarloOutput/MonteCarloOutput_" * string(i))
	filename = "nse_compiled_region.csv"
	MonteCarlo_existing_data = load_dataframe(joinpath(montecarlo_output_path, filename))
	affected_zones = load_dataframe(joinpath(montecarlo_output_path, filename_affected_zones))

	println(affected_zones)

	#affected_zones = [34, 36,35,37,31,38,32,30,33,40,42,41,43,39]

	# affected_zones_set[]
	# A = nrow(affected_zones)

	dfGen = inputs["dfGen"]
	T = inputs["T"]     # Number of time steps (hours)
	Z = inputs["Z"]     # Number of zones
	SEG = inputs["SEG"] # Number of load curtailment segments
	# Non-served energy/demand curtailment by segment in each time step
	dfNse = DataFrame(Segment = repeat(1:SEG, outer = Z), Zone = repeat(1:Z, inner = SEG), AnnualSum = zeros(SEG * Z))
	nse = zeros(SEG * Z, T)
	scale_factor = setup["ParameterScale"] == 1 ? ModelScalingFactor : 1
	for row in eachrow(affected_zones)#1:Z
		print(row)
		z = row["Affected_Zones"]
		nse[((z-1)*SEG+1):z*SEG, :] = value.(EP[:vNSE])[:, :, z] * scale_factor
	end
	dfNse.AnnualSum .= nse * inputs["omega"]
	dfNse = hcat(dfNse, DataFrame(nse, :auto))
	auxNew_Names=[Symbol("Segment");Symbol("Zone");Symbol("AnnualSum");[Symbol("t$t") for t in 1:T]]
	rename!(dfNse,auxNew_Names)

	total = DataFrame(["Total" 0 sum(dfNse[!,:AnnualSum]) fill(0.0, (1,T))], :auto)
	total[:, 4:T+3] .= sum(nse, dims = 1)
	rename!(total,auxNew_Names)
	dfNse = vcat(dfNse, total)

	# print(MonteCarlo_existing_data)
	# print(total)
	
	MonteCarlo_existing_data = vcat(MonteCarlo_existing_data, total)
	# MonteCarlo_existing_data = append!(total, MonteCarlo_existing_data)

	

	CSV.write(joinpath(montecarlo_output_path, "nse_compiled_region.csv"),  MonteCarlo_existing_data, writeheader=true)
	# CSV.write(joinpath(path, "nse.csv"),  dftranspose(total, false), writeheader=false)


	return total
end
