# Long Duration Storage
```@autodocs
Modules = [GenX]
Pages = ["long_duration_storage.jl"]
```