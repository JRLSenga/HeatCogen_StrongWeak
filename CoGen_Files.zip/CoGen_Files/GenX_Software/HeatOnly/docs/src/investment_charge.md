# Investment Charge
```@autodocs
Modules = [GenX]
Pages = ["investment_charge.jl"]
```
