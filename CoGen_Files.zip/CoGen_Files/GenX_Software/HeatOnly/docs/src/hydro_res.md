# Hydro Resources
```@autodocs
Modules = [GenX]
Pages = ["hydro_res.jl"]
```