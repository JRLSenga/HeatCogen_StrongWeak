# Thermal No Commit
```@autodocs
Modules = [GenX]
Pages = ["thermal_no_commit.jl"]
```