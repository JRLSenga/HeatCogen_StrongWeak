function write_start(path::AbstractString, inputs::Dict, setup::Dict, EP::Model)
	dfGen = inputs["dfGen"]
	G = inputs["G"]     # Number of resources (generators, storage, DR, and DERs)
	T = inputs["T"]     # Number of time steps (hours)
	COMMIT = inputs["COMMIT"]
	# Startup state for each resource in each time step
	dfStart = DataFrame(Resource = inputs["RESOURCES"], Zone = dfGen[!, :Zone])
	start = zeros(G,T)
	start[COMMIT, :] = value.(EP[:vSTART][COMMIT, :])
	dfStart.AnnualSum = start * inputs["omega"]
	dfStart = hcat(dfStart, DataFrame(start, :auto))
	auxNew_Names=[Symbol("Resource");Symbol("Zone");Symbol("AnnualSum");[Symbol("t$t") for t in 1:T]]
	rename!(dfStart,auxNew_Names)

	total = DataFrame(["Total" 0 sum(dfStart.AnnualSum) fill(0.0, (1,T))], :auto)
	total[:, 4:T+3] .= sum(start, dims = 1)
	rename!(total,auxNew_Names)
	dfStart = vcat(dfStart, total)
	CSV.write(joinpath(path, "start_PureElectricity.csv"), dftranspose(dfStart, false), writeheader=false)




	dfStart_B = DataFrame(Resource = inputs["RESOURCES"], Zone = dfGen[!, :Zone])
	start_B = zeros(G,T)
	start_B[COMMIT, :] = value.(EP[:vSTART_B][COMMIT, :])
	dfStart_B.AnnualSum = start_B * inputs["omega"]
	dfStart_B = hcat(dfStart_B, DataFrame(start_B, :auto))
	auxNew_Names_B=[Symbol("Resource");Symbol("Zone");Symbol("AnnualSum");[Symbol("t$t") for t in 1:T]]
	rename!(dfStart_B,auxNew_Names_B)

	total_B = DataFrame(["Total" 0 sum(dfStart_B.AnnualSum) fill(0.0, (1,T))], :auto)
	total_B[:, 4:T+3] .= sum(start_B, dims = 1)
	rename!(total_B,auxNew_Names_B)
	dfStart_B = vcat(dfStart_B, total_B)
	CSV.write(joinpath(path, "start_Process.csv"), dftranspose(dfStart_B, false), writeheader=false)
end
