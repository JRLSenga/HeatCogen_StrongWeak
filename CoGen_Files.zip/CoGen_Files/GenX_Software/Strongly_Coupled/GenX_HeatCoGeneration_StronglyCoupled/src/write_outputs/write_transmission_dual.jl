@doc raw"""
	write_price(path::AbstractString, inputs::Dict, setup::Dict, EP::Model)

Function for reporting marginal electricity price for each model zone and time step. Marginal electricity price is equal to the dual variable of the load balance constraint. If GenX is configured as a mixed integer linear program, then this output is only generated if `WriteShadowPrices` flag is activated. If configured as a linear program (i.e. linearized unit commitment or economic dispatch) then output automatically available.
"""
function write_transmission_dual(path::AbstractString, inputs::Dict, setup::Dict, EP::Model)
	L = inputs["L"]     # Number of transmission lines

	## Extract dual variables of constraints
	# Electricity price: Dual variable of hourly power balance constraint = hourly price
	dfTransmission = DataFrame(Line = 1:L) # The unit is $/MWh
	scale_factor = setup["ParameterScale"] == 1 ? ModelScalingFactor : 1
	# Dividing dual variable for each hour with corresponding hourly weight to retrieve marginal cost of generation
	println(dual.(EP[:cMaxLineReinforcement]))

	
	dfTransmission = convert_jump_container_to_df(dual.(EP[:cMaxLineReinforcement]))
	dfTransmission = insertcols!(dfTransmission, 3, :Current_Max_Line_Reinforcement => inputs["pMax_Line_Reinforcement"])
	
	print(dfTransmission)

	MinimumDual = findfirst(==(minimum(dfTransmission.Value)), dfTransmission.Value)


	CSV.write(joinpath(path, "transmission_dual.csv"), dfTransmission, writeheader=true)

	# exit()
	# #write new network file
	# filename_network = "Network.csv"
	# network_input = load_dataframe(joinpath(path, filename_network))
	# network_input = select!(network_input, Not(:Line_Max_Reinforcement_MW))

    # network_input[!, "Line_Max_Reinforcement_MW"] = inputs["pMax_Line_Reinforcement"]

    # CSV.write(joinpath(path, "Network.csv"), network_input)

	# return dfTransmission
end


"""
Returns a `DataFrame` with the values of the variables from the JuMP container `var`.
The column names of the `DataFrame` can be specified for the indexing columns in `dim_names`,
and the name of the data value column by a Symbol `value_col` e.g. :Value
"""
function convert_jump_container_to_df(var::JuMP.Containers.DenseAxisArray;
    dim_names::Vector{Symbol}=Vector{Symbol}(),
    value_col::Symbol=:Value)

    if isempty(var)
        return DataFrame()
    end

    if length(dim_names) == 0
        dim_names = [Symbol("dim$i") for i in 1:length(var.axes)]
    end

    if length(dim_names) != length(var.axes)
        throw(ArgumentError("Length of given name list does not fit the number of variable dimensions"))
    end

    tup_dim = (dim_names...,)

    # With a product over all axis sets of size M, form an Mx1 Array of all indices to the JuMP container `var`
    ind = reshape([collect(k[i] for i in 1:length(dim_names)) for k in Base.Iterators.product(var.axes...)],:,1)

    var_val  = value.(var)

    df = DataFrame([merge(NamedTuple{tup_dim}(ind[i]), NamedTuple{(value_col,)}(var_val[(ind[i]...,)...])) for i in 1:length(ind)])

    return df
end