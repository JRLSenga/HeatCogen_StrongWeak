################################################################################
## function output
##
## description: Writes results to multiple .csv output files in path directory
##
## returns: n/a
################################################################################
@doc raw"""
	write_outputs(EP::Model, path::AbstractString, setup::Dict, inputs::Dict)

Function for the entry-point for writing the different output files. From here, onward several other functions are called, each for writing specific output files, like costs, capacities, etc.
"""
function write_outputs_montecarlo(EP::Model, path::AbstractString, setup::Dict, inputs::Dict, i::Int64)

	if setup["OverwriteResults"] == 1
		# Overwrite existing results if dir exists
		# This is the default behaviour when there is no flag, to avoid breaking existing code
		if !(isdir(path))
		mkdir(path)
		end
	else
		# Find closest unused ouput directory name and create it
		path = choose_output_dir(path)
		# mkdir(path)
	end

	# https://jump.dev/MathOptInterface.jl/v0.9.10/apireference/#MathOptInterface.TerminationStatusCode
	status = termination_status(EP)

	## Check if solved sucessfully - time out is included
	if status != MOI.OPTIMAL && status != MOI.LOCALLY_SOLVED
		if status != MOI.TIME_LIMIT # Model failed to solve, so record solver status and exit
			write_status(path, inputs, setup, EP)
			return
			# Model reached timelimit but failed to find a feasible solution
	#### Aaron Schwartz - Not sure if the below condition is valid anymore. We should revisit ####
		elseif isnan(objective_value(EP))==true
			# Model failed to solve, so record solver status and exit
			write_status(path, inputs, setup, EP)
			return
		end
	end

	# write_status(path, inputs, setup, EP)
	elapsed_time_nse = @elapsed write_nse_montecarlo(path, inputs, setup, EP, i)
	elapsed_time_nse_totalUS = @elapsed write_nse_montecarlo_total_US(path, inputs, setup, EP, i)
	println("Time elapsed for writing nse is")
	println(elapsed_time_nse)
	
	## Print confirmation
	println("Wrote outputs to $path")

end # END output()
