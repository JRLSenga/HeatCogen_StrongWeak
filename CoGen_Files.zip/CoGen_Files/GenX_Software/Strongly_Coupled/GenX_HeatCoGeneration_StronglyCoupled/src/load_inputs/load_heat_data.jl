@doc raw"""
	load_load_data!(setup::Dict, path::AbstractString, inputs::Dict)

Read input parameters related to electricity load (demand)
"""
function load_heat_data!(setup::Dict, path::AbstractString, inputs::Dict)

	# Load related inputs
	data_directory = joinpath(path, setup["TimeDomainReductionFolder"])
    if setup["TimeDomainReduction"] == 1  && time_domain_reduced_files_exist(data_directory)
        my_dir = data_directory
	else
        my_dir = path
	end
    filename = "Heat_data.csv"
    heat_in = load_dataframe(joinpath(my_dir, filename))

    as_vector(col::Symbol) = collect(skipmissing(heat_in[!, col]))

	# Number of time steps (periods)
    T = length(as_vector(:Time_Index))
	# Number of demand curtailment/lost load segments
    SEG = length(as_vector(:Demand_Segment))

	## Set indices for internal use
    inputs["T"] = T
    inputs["SEG"] = SEG
	Z = inputs["Z"]   # Number of zones

	inputs["omega"] = zeros(Float64, T) # weights associated with operational sub-period in the model - sum of weight = 8760
    # Weights for each period - assumed same weights for each sub-period within a period
    inputs["Weights"] = as_vector(:Sub_Weights) # Weights each period

    # Total number of periods and subperiods
    inputs["REP_PERIOD"] = convert(Int16, as_vector(:Rep_Periods)[1])
    inputs["H"] = convert(Int64, as_vector(:Timesteps_per_Rep_Period)[1])

    # Creating sub-period weights from weekly weights
    for w in 1:inputs["REP_PERIOD"]
        for h in 1:inputs["H"]
            t = inputs["H"]*(w-1)+h
            inputs["omega"][t] = inputs["Weights"][w]/inputs["H"]
        end
    end

	# Create time set steps indicies
	inputs["hours_per_subperiod"] = div.(T,inputs["REP_PERIOD"]) # total number of hours per subperiod
	hours_per_subperiod = inputs["hours_per_subperiod"] # set value for internal use

	inputs["START_SUBPERIODS"] = 1:hours_per_subperiod:T 	# set of indexes for all time periods that start a subperiod (e.g. sample day/week)
	inputs["INTERIOR_SUBPERIODS"] = setdiff(1:T, inputs["START_SUBPERIODS"]) # set of indexes for all time periods that do not start a subperiod

	# Demand in MW for each zone
	#println(names(heat_in))
	start = findall(s -> s == "Heat_MW_z1", names(heat_in))[1] #gets the starting column number of all the columns, with header "Load_MW_z1"
    scale_factor = setup["ParameterScale"] == 1 ? ModelScalingFactor : 1
    # Max value of non-served energy
    inputs["Voll"] = as_vector(:Voll) / scale_factor # convert from $/MWh $ million/GWh (assuming objective is divided by 1000)
    # Demand in MW
    inputs["pH"] =Matrix(heat_in[1:T, start:start+Z-1]) / scale_factor  # convert to GW

    inputs["Max_HeatDemand"] = maximum(inputs["pH"])


	# Cost of non-served energy/demand curtailment
    # Cost of each segment reported as a fraction of value of non-served energy - scaled implicitly
    inputs["pC_D_Curtail"] = as_vector(:Cost_of_Demand_Curtailment_per_MW) * inputs["Voll"][1]
    # Maximum hourly demand curtailable as % of the max demand (for each segment)
    inputs["pMax_D_Curtail"] = as_vector(:Max_Demand_Curtailment)
    println(inputs["pMax_D_Curtail"])

	println(filename * " Successfully Read!")
end





