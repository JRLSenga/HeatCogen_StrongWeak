@doc raw"""
	discharge(EP::Model, inputs::Dict, setup::Dict)
This module defines the power decision variable $\Theta_{y,t} \forall y \in \mathcal{G}, t \in \mathcal{T}$, representing energy injected into the grid by resource $y$ by at time period $t$.
This module additionally defines contributions to the objective function from variable costs of generation (variable O&M plus fuel cost) from all resources $y \in \mathcal{G}$ over all time periods $t \in \mathcal{T}$:
```math
\begin{aligned}
	Obj_{Var\_gen} =
	\sum_{y \in \mathcal{G} } \sum_{t \in \mathcal{T}}\omega_{t}\times(\pi^{VOM}_{y} + \pi^{FUEL}_{y})\times \Theta_{y,t}
\end{aligned}
```
"""
function heat_discharge!(EP::Model, inputs::Dict, setup::Dict)

	println("Discharge Module")

	dfGen = inputs["dfGen"]


	G = inputs["G"]     # Number of resources (generators, storage, DR, and DERs)
	T = inputs["T"]     # Number of time steps
	Z = inputs["Z"]     # Number of zones
	### Variables ###

	# Heat produced by resource "y" at hour "t"
	@variable(EP, vH[y=1:G,t=1:T] >=0);
	@variable(EP, vH_Industrial[y=1:G,t=1:T] >=0)
	@variable(EP, vH_PureElectricity[y=1:G,t=1:T] >=0)
	@variable(EP, vH_UsableProcessHeat[y=1:G, t=1:T] >=0)


	# ### Expressions ###

	# ## Objective Function Expressions ##

	# # Variable costs of "generation" for resource "y" during hour "t" = variable O&M plus fuel cost

	#Incorporates the PTC incentive if the IRA settings is set to 1.
	if setup["IRA"] == 1 && setup["PTC"] == 1
		# @expression(EP, eCProductionTaxCredit[y=1:G,t=1:T], (inputs["omega"][t]*(dfGen[y,:Production_Tax_Credit_Dollars_MWh])*vP[y,t]))
		@expression(EP, eCFuel[y=1:G,t=1:T], (inputs["omega"][t]*(inputs["C_Fuel_per_MWh"][y,t])*vH[y,t]))
		@expression(EP, eCVarOM[y=1:G,t=1:T], (inputs["omega"][t]*(dfGen[y,:Var_OM_Cost_per_MWh])*vH[y,t]))
		@expression(EP, eCVar_out[y=1:G,t=1:T], (eCVarOM[y,t] + eCFuel[y,t]))
	else
		@expression(EP, eCVar_out[y=1:G,t=1:T], (inputs["omega"][t]*(dfGen[y,:Var_OM_Cost_per_MWh]+inputs["C_Fuel_per_MWh"][y,t])*vH[y,t])) #this is the original line -Juan
	end
	
	#@expression(EP, eCVar_out[y=1:G,t=1:T], (round(inputs["omega"][t]*(dfGen[y,:Var_OM_Cost_per_MWh]+inputs["C_Fuel_per_MWh"][y,t]), digits=RD)*vP[y,t]))
	# Sum individual resource contributions to variable discharging costs to get total variable discharging costs
	
	
	@expression(EP, eTotalCVarOutT[t=1:T], sum(eCVar_out[y,t] for y in 1:G))
	@expression(EP, eTotalCVarOut, sum(eTotalCVarOutT[t] for t in 1:T))

	if setup["IRA"] == 1 && setup["PTC"] == 1
		#for separate output of Production Tax Credits, fuel costs, and variable OM --Juan
		# @expression(EP, eTotalCProductionTaxCreditT[t=1:T], sum(eCProductionTaxCredit[y,t] for y in 1:G))
		# @expression(EP, eTotalCProductionTaxCredit, sum(eTotalCProductionTaxCreditT[t] for t in 1:T))

		@expression(EP, eTotalCFuelT[t=1:T], sum(eCFuel[y,t] for y in 1:G))
		@expression(EP, eTotalCFuel, sum(eTotalCFuelT[t] for t in 1:T))

		@expression(EP, eTotalCVarOMT[t=1:T], sum(eCVarOM[y,t] for y in 1:G))
		@expression(EP, eTotalCVarOM, sum(eTotalCVarOMT[t] for t in 1:T))


		#regional cost breakdown - Juan
		# @expression(EP, eTotalCProductionTaxCredit_Zone[z=1:Z], sum(eCProductionTaxCredit[y,t] for y=dfGen[findall(x->x==z,dfGen[!,"Zone"]),:R_ID], t = 1:T))
		@expression(EP, eTotalCFuel_Zone[z=1:Z], sum(eCFuel[y,t] for y=dfGen[findall(x->x==z,dfGen[!,"Zone"]),:R_ID], t = 1:T))
		@expression(EP, eTotalCVarOM_Zone[z=1:Z], sum(eCVarOM[y,t] for y=dfGen[findall(x->x==z,dfGen[!,"Zone"]),:R_ID], t = 1:T))
	end

	

	# Add total variable discharging cost contribution to the objective function
	EP[:eObj] += eTotalCVarOut


end
