@doc raw"""
	emissions(EP::Model, inputs::Dict)

This function creates expression to add the CO2 emissions by plants in each zone, which is subsequently added to the total emissions
"""
function emissions!(EP::Model, inputs::Dict, setup::Dict)

	println("Emissions Module (for CO2 Policy modularization")

	dfGen = inputs["dfGen"]

	G = inputs["G"]     # Number of resources (generators, storage, DR, and DERs)
	T = inputs["T"]     # Number of time steps (hours)
	Z = inputs["Z"]     # Number of zones

	@expression(EP, eEmissionsByPlant[y=1:G,t=1:T],

		if y in inputs["COMMIT"]
			dfGen[y,:CO2_per_MWh]*EP[:vP][y,t]+dfGen[y,:CO2_per_Start]*EP[:vSTART][y,t]
		else
			dfGen[y,:CO2_per_MWh]*EP[:vP][y,t]
		end
	)

	#creates a cost reduction for when IRA and CCS Incentive is active -- Juan
	if setup["IRA"] == 1 && setup["CCS_Incentive"] == 1
		@expression(EP, eCCO2CaptureIncentive[y=1:G,t=1:T],

		if y in inputs["CCS_Incentive_Eligible"]
			eEmissionsByPlant[y, t]*(dfGen[y,:CCS_Rate]/(1-dfGen[y,:CCS_Rate]))*dfGen[y,:Captured_CO2_Incentive_PerMetricTon]
		else
			0
		end
		)
	
		#subtract captured CO2 incentive from objective function -- Juan
		@expression(EP, eTotalCCO2CaptureIncentiveT[t=1:T], sum(eCCO2CaptureIncentive[y,t] for y in 1:G))
		@expression(EP, eTotalCCO2CaptureIncentive, sum(eTotalCCO2CaptureIncentiveT[t]*inputs["omega"][t] for t in 1:T))

		#regional cost breakdown - Juan
		@expression(EP, eTotalCCO2CaptureIncentive_Zone[z=1:Z], sum(eCCO2CaptureIncentive[y,t] for y=dfGen[findall(x->x==z,dfGen[!,"Zone"]),:R_ID], t = 1:T))

		EP[:eObj] -= eTotalCCO2CaptureIncentive #--Juan

	end


	@expression(EP, eEmissionsByZone[z=1:Z, t=1:T], sum(eEmissionsByPlant[y,t] for y in dfGen[(dfGen[!,:Zone].==z),:R_ID]))

	#includes a social cost of carbon that is input by the user
	# EP[:eObj] += sum(eEmissionsByZone[z, t] for z=1:Z, t=1:T)*190 #-Juan Senga
end
