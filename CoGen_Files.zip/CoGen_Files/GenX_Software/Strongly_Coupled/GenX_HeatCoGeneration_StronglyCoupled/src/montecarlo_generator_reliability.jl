


function montecarlo_generator_reliability(path::AbstractString,iteration_number::Integer,filename::AbstractString, generator_path::AbstractString)

    println("Generating MonteCarlo iteration")
    
    println(path)
    
    MonteCarlo_data = load_dataframe(joinpath(path, filename))

    affected_percentage = 0.8
    column_name = "Scenario_" * string(affected_percentage) * "_" * string(iteration_number)
    column_name = Symbol(column_name)
    println(column_name)
    iteration_data = MonteCarlo_data[:,[column_name]]
    # print(iteration_data)


    filename_generators = "Generators_data.csv"
    filepath_generator_variability = "TDR_Results/Generators_variability.csv"

    

    generator_input = load_dataframe(joinpath(generator_path, filename_generators))
    # generator_variability = load_dataframe(joinpath(generator_path, filepath_generator_variability))
    # print(generator_variability)

    # exit()



    # existing_cap_label = "Existing_Cap_MW"
    generator_input = select!(generator_input, Not(:Existing_Cap_MW))

    generator_input[!, "Existing_Cap_MW"] = iteration_data[!,:"Scenario_" * string(affected_percentage) * "_" * string(iteration_number)]
    # generator_input["Existing_Cap_MW"] = iteration_data[!,:column_name]

    CSV.write(joinpath(generator_path, "Generators_data.csv"), generator_input)


end

function montecarlo_generator_variability_reliability(path::AbstractString,iteration_number::Integer,filename::AbstractString, generator_path::AbstractString)

    println("Generating MonteCarlo iteration")
    
    println(path)
    
    MonteCarlo_data = load_dataframe(joinpath(path, filename))

    affected_percentage = 0.8

    column_name = "Scenario_" * string(affected_percentage) * "_" * string(iteration_number)
    column_name = Symbol(column_name)
    println(column_name)
    iteration_data = MonteCarlo_data[:,[column_name]]
    # print(iteration_data)


    filename_generators = "Generators_data.csv"


    

    generator_input = load_dataframe(joinpath(generator_path, filename_generators))
    # generator_variability = load_dataframe(joinpath(generator_path, filepath_generator_variability))
    # print(generator_variability)

    # exit()



    #determines the scaling that will hapen for affected generators
    generator_input = select!(generator_input, :Existing_Cap_MW, :Testing, :Resource)

    generator_input[!, "Existing_Cap_MW"] =  iteration_data[!,:"Scenario_" * string(affected_percentage) * "_" * string(iteration_number)] ./ generator_input[!, "Existing_Cap_MW"]

    

    # exit()
    # generator_input["Existing_Cap_MW"] = iteration_data[!,:column_name]

    # CSV.write(joinpath(generator_path, "Generators_data.csv"), generator_input)

    # Hourly capacity factors
	
    G = nrow(MonteCarlo_data)
    

    # filename_generators_variability_original = "Generators_variability_original.csv"
    # generator_variability_path = joinpath(generator_path, "TDR_Results")
    # generator_variability = load_dataframe(joinpath(generator_variability_path, filename_generators_variability_original))
    
    
    # for row in eachrow(generator_input)
    #     if ismissing(row["Testing"]) == false
    #         resource_name = row["Resource"]
    #         resource_name = Symbol(resource_name)
    #         # println(resource_name)
    #         generator_variability[!,Symbol(resource_name)] = generator_variability[!,Symbol(resource_name)] .* row["Existing_Cap_MW"]
    #         # generator_variability[!,:[resource_name]] = generator_variability[!,:[resource_name]] / row["Existing_Cap_MW"]
    #         # print(generator_variability[!,:[resource_name]])
    #         # println(row["Existing_Cap_MW"])
    #         # println(generator_variability[!,Symbol(resource_name)])

    #         # generator_variability[generator_input.Testing .== "Elliot",generator_variability.resource_name] .= 0.0
    #     end
    # end


    # CSV.write(joinpath(generator_variability_path, "Generators_variability.csv"), generator_variability)

    # exit()

    # all_resources = inputs["RESOURCES"]

    # existing_variability = names(generator_variability)

	# Reorder DataFrame to R_ID order (order provided in Generators_data.csv)
	# select!(generator_variability, [:Time_Index; Symbol.(all_resources) ])

	# Maximum power output and variability of each energy resource
	# variability = transpose(Matrix{Float64}(generator_variability[1:480,2:(1221+1)]))
    # variability = transpose(Matrix{Float64}(generator_variability[1:inputs["T"],2:(inputs["G"]+1)]))


end