# Thermal Commit
```@autodocs
Modules = [GenX]
Pages = ["thermal_commit.jl"]
```