# Investment Energy
```@autodocs
Modules = [GenX]
Pages = ["investment_energy.jl"]
```