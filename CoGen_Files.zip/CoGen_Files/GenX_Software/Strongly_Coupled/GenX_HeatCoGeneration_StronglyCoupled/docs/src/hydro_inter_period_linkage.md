# Reservoir Hydro
```@autodocs
Modules = [GenX]
Pages = ["hydro_inter_period_linkage.jl"]
```