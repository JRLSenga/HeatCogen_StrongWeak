# Thermal
```@autodocs
Modules = [GenX]
Pages = ["thermal.jl"]
```