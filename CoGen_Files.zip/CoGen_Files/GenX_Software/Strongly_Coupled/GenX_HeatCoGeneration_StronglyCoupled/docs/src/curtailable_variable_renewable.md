# Curtailable Variable Renewables
```@autodocs
Modules = [GenX]
Pages = ["curtailable_variable_renewable.jl"]
```