# Storage
```@autodocs
Modules = [GenX]
Pages = ["storage.jl"]
```
