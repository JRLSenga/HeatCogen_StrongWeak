# Documentation
```@autodocs
Modules = [GenX]
Pages = ["documentation.jl"]
```